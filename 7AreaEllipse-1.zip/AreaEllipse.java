public class AreaEllipse {

	public static void main(String[] args) {
		float pi = 3.14f;
		int r1 = 4;
		int r2 = 6;
		
		System.out.println("A ellipse has two distances, namely, "
				+ r1 + " and " + r2 + " so, \nif we get the area of this shape,"
				+ " then, the answer is " + pi*r1*r2 + ".");
	}

}
