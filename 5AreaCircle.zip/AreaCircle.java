public class AreaCircle {

	public static void main(String[] args) {
		float pi = 3.14f;
		int r = 6;
		float circle = pi*r; 
		
		System.out.println("The area of circle is calculated by multiplying pi \nwhich is "
				+ pi + " with a radius of " + r + " is " + circle + "." );
	}

}
