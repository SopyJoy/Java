import java.util.Scanner;

public class AreaSquare {

	public static void main(String[] args) {
		Scanner square = new Scanner(System.in);
		int a;
		System.out.println("Enter a value for a: ");
		a = square.nextInt();
		
		int aSquared = a*a;
		System.out.println("The squared value for " + a + " is " + aSquared);

	}

}
