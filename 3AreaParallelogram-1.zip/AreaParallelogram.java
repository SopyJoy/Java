public class AreaParallelogram {

	public static void main(String[] args) {
		int b= 2;
		int h= 4;
		int bhProduct = b*h;
	
		System.out.println("The area of parallelogram having " + b
				+ " as base and " + h + " as height is " + bhProduct + ".");
	}

}
