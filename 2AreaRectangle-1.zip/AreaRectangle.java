import java.util.Scanner;

public class AreaRectangle {

	public static void main(String[] args) {
		Scanner rectangle = new Scanner(System.in);
		int b;
		int a;
		
		System.out.println("Enter the value for a: ");
		a = rectangle.nextInt();
		System.out.println("Enter the value for b: ");
		b = rectangle.nextInt();
		
		int abProduct = a*b;
		System.out.println("The area of a recatangle with " 
				+ a + " and " + b + " sides is " + abProduct);

	}

}
