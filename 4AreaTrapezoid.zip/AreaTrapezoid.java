public class AreaTrapezoid {

	public static void main(String[] args) {
		int b1 = 2;
		int b2 = 4;
		int h = 6;
		int sum = b1 + b2;
		int average = h/2;
		
		System.out.println("The trapezoid's value for base one is " + b1 +
				" , the value for base two is " + b2 + " and the height is " + h + ".");
		System.out.println("Knowing that, the area of trapezoid is " + sum * average + ".");
		
	}

}
