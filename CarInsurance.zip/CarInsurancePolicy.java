
public class CarInsurancePolicy
{
    public static int policynumber = 123;
    public static int paymentnum = 100;
    public static String residentCity = "Angeles";
     public static void main(String[] args){

         carInsurancePolicy(policynumber, paymentnum, residentCity);
         carInsurancePolicy(policynumber, paymentnum);
         carInsurancePolicy(policynumber);
       
    }
    
    public static void carInsurancePolicy(int PolicyNumber, int Payment, String ResidentCity){
        System.out.println("The Policy Number: "+PolicyNumber);
        System.out.println("The Number of Payment for the Policy Number: "+Payment);
        System.out.println("The City Residence: "+ResidentCity);
        
    }
    public static void carInsurancePolicy(int PolicyNumber, int Payment){
        System.out.println("The Policy Number: "+PolicyNumber);
        System.out.println("The Number of Payment for the Policy Number: "+Payment);
        System.out.println("The City Residence: "+ residentCity);
        
    }
    public static void carInsurancePolicy(int PolicyNumber){
        System.out.println("The Policy Number: "+PolicyNumber);
        int firstpay = paymentnum;
        int secondpay = 200;
        System.out.println("The First Annual Payment for the Policy Number: "+ firstpay );
        System.out.println("The Second Annual Payment for the Policy Number: "+ secondpay );
        System.out.println("The City Residence: "+residentCity);
        
    }
    
}
