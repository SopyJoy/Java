public class AreaETriangle {

	public static void main(String[] args) {
		int a = 2;
		float b = 0.43f;
		int aSquared = a * a;
		float eTriangle = aSquared * b;
		
		System.out.println("A equilateral triangle has a side of " 
				+ a + " \nand the formula for this is square root of 3 over 4(a^2), "
						+ "\nthus, the area is " + eTriangle + "." );		
	}

}
