public class AreaETriangle {

	public static void main(String[] args) {
		int a = 2;
		float b = 0.75f;
		int aSquared = a * a;
		float eTriangle = aSquared * b;
		
		System.out.println("A equilateral triangle has a side of " 
				+ a + " \nand the formula for this is 3/4(a^2), thus, the area is " + eTriangle);
			
	}

}
