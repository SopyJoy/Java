public class AreaTriangle {

	public static void main(String[] args) {
		int b = 5;
		int h = 9;
		int product = b*h;
		float divide = 0.5f;
		float triangle = divide * product;
		
		System.out.println("A triangle has " + b + " as base and "
				+ h + " as the height. So, if we are getting the area of triangle, "
						+ "\nthen, we need to get the product of the base and height multiply by one half."
				+ "\nThus, the answer is " + triangle + ".");
	}

}
